package com.harrysoft.androidbluetoothserial

class BluetoothConnectException(cause: Throwable) : Exception(cause)
